<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Crud;
use App\File;
use App\Link;
use App\Http\Requests;
use DB;
use App\Http\Controllers\Controller;

class CrudsController extends Controller
{
    public function index()
    {
        $cruds = Crud::all()->toArray();
        $files = File::all()->toArray();
        $files2 = File::all()->toArray();
        $links = Link::all()->toArray();
        return view('crud.index1', compact('cruds','files', 'files2','links'));
    }

    public function getId_1M($id)
    {
        $flag = 0;
        $files = File::all()->toArray();
        $files2 = File::all()->toArray();
        $cruds = Crud::where([
                ['id_1','=',$id],
                ['level','=','M'],
            ])->get();
        $links = Link::all()->toArray();
        return view('crud.index_query',compact('cruds','files','files2','flag','links'));
    }

    public function getId_1S($id)
    {
        $flag = 0;
        $files = File::all()->toArray();
        $files2 = File::all()->toArray();
        $cruds = Crud::where([
                ['id_1','=',$id],
                ['level','=','S'],
            ])->get();
        $links = Link::all()->toArray();
        return view('crud.index_query',compact('cruds','files','files2','flag','links'));
    }

    public function getId_1A($id)
    {
        $flag = 0;
        $files = File::all()->toArray();
        $files2 = File::all()->toArray();
        $cruds = Crud::where([
                ['id_1','=',$id],
                ['level','=','A'],
            ])->get();
        $links = Link::all()->toArray();
        return view('crud.index_query',compact('cruds','files','files2','flag','links'));
    }
 
    public function getLev($level)
    {
        $flag = 1;
        $files = File::all()->toArray();
        $files2 = File::all()->toArray();
        $cruds = Crud::where('level','=',$level)->get();
        $links = Link::all()->toArray();
        return view('crud.index_query',compact('cruds','files','files2','level','flag','links'));
    }

    public function getIdDetail($id)
    {
        $files = File::all()->toArray();
        $files2 = File::all()->toArray();
        $crud = Crud::find($id);
        $cruds = Crud::where('id','=',$crud->id)->get();
        $links = Link::all()->toArray();
        return view('crud.delete',compact('cruds','files','files2','id','links','crud'));
    }

    public function change($id)
    {
        $crud = Crud::find($id);
        $files = File::all()->toArray();
        $links = Link::all()->toArray();
        return view('crud.edit',compact('crud','files','links','id'));
    }

    public function update(Request $request, $id)
    {
        $crud = Crud::find($id);
        $crud->description = $request->get('description');
        $crud->implementation = $request->get('implementation');
        $crud->level = $request->get('level');
        $crud->save();
        return redirect('/cruds');
    }
    
    public function delete($id)
    {
        $crud = Crud::find($id);
        //$file = File::where(['id','=',$id],)->delete();
        $crud->delete();
        return redirect('cruds');
    }

}