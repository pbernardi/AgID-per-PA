<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Link;
use App\Crud;
use App\Http\Controllers\Controller;
use Validator;
use Input;

class LinkController extends Controller
{

	public function create($id)
	{
		$crud = Crud::find($id);
		return view('link.create', compact('crud'));
	}

	public function store(Request $request, $id)
	{
		$link = new Link;
		$link->name = $request->get('name');
        $link->link = $request->get('link');
        $crud = Crud::find($id);
        $link->id_crud = $crud->id;
		$link->save();
		return redirect('cruds');

	}

	public function edit($id)
	{
		$link = Link::find($id);
		return view('link.edit',compact('link','id'));
	}

    public function update(Request $request, $id)
    {
    	$link = Link::find($id);
        $link->name = $request->get('name');
        $link->link= $request->get('link');
        $link->save();
        return redirect('cruds');
    }

    public function delete($id)
    {
    	$link = Link::find($id);
    	$link->delete();
    	return back();
    }
}
