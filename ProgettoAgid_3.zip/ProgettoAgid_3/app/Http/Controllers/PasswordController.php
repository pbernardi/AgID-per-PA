<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\User;


class PasswordController extends Controller
{
    public function index($id)
    {
    	$user = User::find($id);
    	return view('auth.edit',compact('user'));
    }

    public function update(Request $request)
    {
    	$request->user()->fill([
    		'email' => $request->get('email'),
    		'name' => $request->get('name'),
    		'password' => bcrypt($request->password), //$request->password points in "password" column in "users"
    	])->save();
    	
    	return redirect('/');
    }

}
