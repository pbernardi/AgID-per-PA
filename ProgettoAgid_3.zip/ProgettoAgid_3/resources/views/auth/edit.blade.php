<!DOCTYPE html>
<html>

	<head>

		<link href="css/welc_logged.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/edit.css') }}">
        <link rel="stylesheet" type="text/css" href="{{ asset('css/index.css') }}">
		<link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.min.css') }}">
		<!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">
	</head>

	<body>
		@if(Auth::user())
		<header>
			<nav class="navbar navbar-default navbar-fixed-top">
			    <div id="container" class="container">
			        <div class="navbar-header page-scroll">
			            <div id="dropdown" class="dropdown">
			                <button onclick="myFunction()" class="dropbtn" id="user"> {{ Auth::user()->name }} <i class="fa fa-angle-down fa-lg"></i>  </button>
			                <div id="myDropdown" class="dropdown-content">
			                    <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">Logout</a>
			                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;"> {{ csrf_field() }} </form>
			                </div>
			            </div>
			        	<a class="navbar-brand" href="{{ URL('/') }}" id="home">Home</a>
			        </div>
			    </div>
			</nav>
	    </header>

	    <br><br><br>
	    <p align="center" style="font-size: 20px;">Qui puoi cambiare i tuoi dati di accesso</p>
	    <br><br><br><br><br><br><br><br><br>
	    <form method="POST" action="{{ action('PasswordController@update',$user['id']) }}" onsubmit="return check(this)">
			{{ csrf_field() }}

			<div class="col-lg-12 text-left" align="center">
			    <div class="form-group text-left">
			    	<div class="col-xs-9">
			    		<label class="col-xs-3 control-label">Nome Utente</label>
						<input type="text" name="name" value="{{ $user->name }}" required>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						<label class="col-xs-3 control-label">Email Utente</label>
						<input type="email" name="email" value="{{ $user->email }}">
					</div>
				</div>

				<br><br>

				<div class="col-sm-10">
			    	<label class="col-xs-3 control-label" >Password</label>
			    	<div class="col-xs-9">
						<input pattern=".{8,}" title="La password deve avere almeno 8 caratteri." type="password" name="password" required>
					</div>
				</div>

				<br><br>

				<div class="col-sm-10">
			    	<label class="col-xs-3 control-label">Conferma Password</label>
			    	<div class="col-xs-9">
						<input type="password" name="password2" required>
					</div>
				</div>

				<br><br><br><br>

				<div class="form-group row">
					<button id="elimina" type="submit" class="btn btn-primary" style="position: relative; left: 1px;"><i class="fa fa-pencil fa-lg">&nbsp;&nbsp;&nbsp;</i>Modifica</button>
				</div>
			</div>

			<br><br><br><br><br>
		</form>
		<div id="navcnt">
			<a href="{{ action('CrudsController@index') }}" class="btn btn-warning">
				<button id="indietro" class="bnt btn-warning"><i class="fa fa-undo fa-lg">&nbsp;&nbsp;&nbsp;</i>Indietro</button>
			</a>
		</div>
		<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
		@endif
		@if(Auth::guest())
			<br><br><br><br>
			<div align="center">
		    <a href="{{ URL('/') }}" class="btn btn-danger">
					<button id="btn_expire"></button>
				</a>
			</div>
			<p align="center" style="font-size: 25px; font-family: sans-serif;">La sessione è scaduta</p>
		@endif
	</body>

	<script type="text/javascript">
		
		function myFunction() {
    		document.getElementById("myDropdown").classList.toggle("show");
		}
		window.onclick = function(event) {
    		if (!event.target.matches('.dropbtn')) {

        		var dropdowns = document.getElementsByClassName("dropdown-content");
        		var i;
        		for (i = 0; i < dropdowns.length; i++) {
            		var openDropdown = dropdowns[i];
            		if (openDropdown.classList.contains('show')) {
                		openDropdown.classList.remove('show');
            		}
        		}
    		}
		}

	</script>
	<script type="text/javascript">
		function check(modulo)
		{
			if(modulo.password.value != modulo.password2.value)
			{
				alert("Le password sono diverse.");
				modulo.password.focus()
				modulo.password.select()
				return false
			}
			return true
		}
	</script>
</html>