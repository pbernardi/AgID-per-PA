<!DOCTYPE html>
<html>

	<head>
		<title>Elimina</title>
		<link rel="stylesheet" type="text/css" href="{{ asset('css/delete.css') }}">
		<link rel="stylesheet" type="text/css" href="{{ asset('css/font-awesome.min.css') }}">
	</head>

	<body>
		@if(Auth::user())
		<div>
			<div id="foot" role="navigation">
				<div data-jibp="h" data-jiis="uc" id="cljs"></div>
				<span data-jibp="h" data-jiis="ic" id="xjs">
					<div id="navcnt">
						<p align="center">Sicuro di voler procedere all'<b>eliminazione</b> del punto <b>{{ $crud->id_1 }}.{{ $crud->id_2 }}.{{ $crud->id_3 }}</b> ? Premi "Elimina" per procedere, "Indietro" per annullare</p>
						<br><br><br><br><br><br>
					</div>
				</span>
			</div>
		</div>

		<div class="container">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>ID_1</th>
						<th>ID_2</th>
						<th>ID_3</th>
						<th>Descrizione</th>
						<th>Implementazione</th>
						<th>Livello</th>
						<th colspan="2">Azioni</th>
					</tr>
				</thead>
				<tbody>
					@foreach($cruds as $post)
					<tr>
						<td id="id">{{ $post['id_1'] }}</td>
						<td id="id">{{ $post['id_2'] }}</td>
						<td id="id">{{ $post['id_3'] }}</td>
						<td id="desc">{{ $post['description'] }}</td>
						<td id="impl">{{ $post['implementation'] }}</td>
						<td id="lev">{{ $post['level'] }}</td>
						<td id="action" align="center">
							<a href="{{ action('CrudsController@delete',$post['id']) }}" class="btn btn-warning">
								<button id="elimina" class="btn btn-danger" type="submit"><i class="fa fa-trash fa-lg">&nbsp;&nbsp;&nbsp;</i>Elimina</button>
							</a>
						</td>
					</tr>
					@endforeach
				</tbody>
			</table>
		</div>
		<br><br><br><br>
		<a href="{{ action('CrudsController@index') }}" class="btn btn-warning" >
			<button id="indietro" class="btn btn-danger" type="submit"><i class="fa fa-undo fa-lg">&nbsp;&nbsp;&nbsp;</i> Indietro</button>
		</a>
		@endif
		@if(Auth::guest())
		<br><br><br><br>
		<div align="center">
	    <a href="{{ URL('/') }}" class="btn btn-danger">
				<button id="btn_expire" ></button>
			</a>
		</div>
		<p align="center" style="font-size: 25px; font-family: sans-serif;">La sessione è scaduta</p>
		@endif
	</body>
</html>