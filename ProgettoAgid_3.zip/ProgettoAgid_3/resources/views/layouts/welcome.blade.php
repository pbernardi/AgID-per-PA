<!DOCTYPE html>
<html lang="{{ app()->getLocale() }}">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Provincia di Treviso</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link href="css/welc_logged.css" rel="stylesheet" type="text/css">
        <link href="css/welc_log.css" rel="stylesheet" type="text/css">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

    </head>

    <body id="page-top">

        @if (Auth::user())
        
          @include('welc_logged')

        @endif

        @if (Auth::guest())
         
          @include('welc_log')

        @endif

    <!-- ---------- JavaScript ---------- -->
    <script>
    //When the user clicks on the button, toggle between hiding and showing the dropdown content
    function myFunction() {
        document.getElementById("myDropdown").classList.toggle("show");
    }
    // Close the dropdown if the user clicks outside of it
    window.onclick = function(e)
    { 
        if (!e.target.matches('.dropbtn'))
        {
            var myDropdown = document.getElementById("myDropdown");
            if (myDropdown.classList.contains('show'))
                myDropdown.classList.remove('show');
        }
    }
    </script>

    </body>
</html>