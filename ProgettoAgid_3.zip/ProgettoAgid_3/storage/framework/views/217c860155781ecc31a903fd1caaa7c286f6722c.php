<!DOCTYPE html>
<html>

    <head>

        <link href="css/welc_log.css" rel="stylesheet" type="text/css">

    </head>

	<body>

		<div class="content">

            <img id="agidlogo" src="http://www.opencityplatform.eu/wp-content/uploads/2015/07/AGID_logo_web3.jpg" alt="AgID logo" width="540">
            <img id="pvtlogo" src="http://www.judovittorioveneto.net/wp-content/uploads/logo_pp5.jpg" alt="AgID logo" width="562">

        </div>

        <div class="content_form">

            <form class="form-horizontal" id="login" method="POST" novalidate action="<?php echo e(route('login')); ?>"> 
                <?php echo e(csrf_field()); ?>


                <div id="email" class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="email" class="col-md-4 control-label"> <b>Nome Utente</b> </label>

                    <div class="col-md-6">
                        <input type="text" class="form-control" name="name" value="<?php echo e(old('name')); ?>" required autofocus">

                        <?php if($errors->has('name')): ?>
                            <span class="help-block">
                                <strong><nobr><?php echo e($errors->first('name')); ?></nobr></strong> <!-- <nobr> = no a capo -->
                            </span>
                        <?php endif; ?>
                    </div>
                    
                </div>

                <div id="password" class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password" class="col-md-4 control-label"> <b>Password</b> </label>

                    <div class="col-md-6">
                        <input type="password" class="form-control" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><nobr><?php echo e($errors->first('password')); ?></nobr></strong> <!-- <nobr> = no a capo -->
                            </span>
                        <?php endif; ?>
                    </div>

                </div>

                <div class="form-group">
                    <div class="col-md-8 col-md-offset-4">
                        <button type="submit" class="btn btn-primary" id="buttonsubmit">
                            Login
                        </button>
                    </div>
                </div>

            </form>

        </div>
        
	</body>

</html>