<!DOCTYPE html>
<html>
	<head>
		<title>Aggiungi</title>
		<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/edit.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/upload.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">
	</head>
	<body>
		<?php if(Auth::user()): ?>
		<div class="container" align="center">
			<br><br><br><br>
		<p align="center">Puoi aggiungere una nuova risorsa compilando questo form e premendo <b><u>Aggiungi</u></b>.</p>
		<br><br><br><br>
			<form method="POST" action="<?php echo e(action('LinkController@store',$crud['id'])); ?>">
			<?php echo e(csrf_field()); ?>

				<table class="table table-striped">
					<thead>
						<tr>
							<th>Nome</th>
							<th>Link</th>
						</tr>
					</thead>
					<tbody>
						<tr align="center">
							<td>
								<div class="col-sm-10">
									<textarea name="name" rows="2" cols="70"></textarea>
								</div>
							</td>
							<td>
								<div class="form-group row">
									<div class="col-sm-10">
										<textarea name="link" rows="2" cols="70"></textarea>
									</div>
								</div>
							</td>
							<td id="button">
								<div class="form-group row">
									<button id="elimina" type="submit" class="btn btn-primary"><i class="fa fa-plus fa-lg">&nbsp;&nbsp;&nbsp;</i>Aggiungi</button>
								</div>
							</td>
						</tr>
					</tbody>
				</table>
			</form>
		</div>
		<br><br><br><br><br>
		<a href="<?php echo e(action('CrudsController@index')); ?>" class="btn btn-warning" >
			<button id="indietro" class="btn btn-danger" type="submit"><i class="fa fa-undo fa-lg">&nbsp;&nbsp;&nbsp;</i> Indietro</button>
		</a>
		<br><br><br><br><br><br><br><br><br>
		<?php endif; ?>
		<?php if(Auth::guest()): ?>
			<br><br><br><br>
			<div align="center">
		    <a href="<?php echo e(URL('/')); ?>" class="btn btn-danger">
					<button id="btn_expire" ></button>
				</a>
			</div>
			<p align="center" style="font-size: 25px; font-family: sans-serif;">La sessione è scaduta</p>
		<?php endif; ?>
	</body>
</html>