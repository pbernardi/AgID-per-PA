<!DOCTYPE html>
<html>
<head>
	<title>Modifca</title>

	<!-- font e css -->
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/edit.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/upload.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.min.css')); ?>">

</head>
<body>
	<div class="container" align="center">
		<br><br><br><br>
		<p align="center">Sicuro di voler procedere alla<b> modifica</b>? Premi "Modifica" per procedere, "Indietro" per annullare.</p>
		<br><br><br><br>
		<form method="POST" action="<?php echo e(action('LinkController@update',$id)); ?>">
		<?php echo e(csrf_field()); ?>

			<table class="table table-striped">
				<thead>
					<tr>
						<th>Nome</th>
						<th>Link</th>
						<th colspan="3" align="center">Azioni</th>
					</tr>
				</thead>
				<tbody>
					<tr align="center">
						<td>
							<div class="col-sm-10">
								<textarea name="name" rows="2" cols="70" style="text-align: center;"><?php echo e($link->name); ?></textarea>
							</div>
						</td>
						<td>
							<div class="form-group row">
								<div class="col-sm-10">
									<textarea name="link" rows="2" cols="70" style="text-align: center;"><?php echo e($link->link); ?></textarea>
								</div>
							</div>
						</td>
						<td id="button">
							<div class="form-group row">
								<button id="elimina" type="submit" class="btn btn-primary"><i class="fa fa-pencil fa-lg">&nbsp;&nbsp;&nbsp;</i>Modifica</button>
							</div>
						</td>
					</tr>
				</tbody>
			</table>
		</form>
		<br><br><br><br><br>
		<div id="navcnt">
			<a href="<?php echo e(action('CrudsController@change',$link['id_crud'])); ?>" class="btn btn-warning">
				<button id="indietro" class="bnt btn-warning" type="submit"><i class="fa fa-undo fa-lg">&nbsp;&nbsp;&nbsp;</i> Indietro</button>
			</a>
		</div>
	</div>
</body>
</html>