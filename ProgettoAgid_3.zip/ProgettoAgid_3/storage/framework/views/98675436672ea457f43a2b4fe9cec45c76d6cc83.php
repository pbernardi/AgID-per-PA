<!DOCTYPE html>
<html>

	<head>
		<link href="css/index.blade.css" rel="stylesheet" type="text/css">
	</head>

	<body>

		<div>
			<h1>Id 1</h1>
			<div id="foot" role="navigation">
				<div data-jibp="h" data-jiis="uc" id="cljs"></div>
				<span data-jibp="h" data-jiis="ic" id="xjs">
					<div id="navcnt">

					</div>
				</span>
			</div>
		</div>

		<div class="container">
			<table class="table table-striped">
				<thead>
					<tr>
						<th>ID_1</th>
						<th>ID_2</th>
						<th>ID_3</th>
						<th>Descrizione</th>
						<th>Implementazione</th>
						<th>Livello</th>
						<th colspan="2">Azioni</th>
					</tr>
				</thead>
				<tbody>
					<?php $__currentLoopData = $cruds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td id="id"><?php echo e($post['id_1']); ?></td>
						<td id="id"><?php echo e($post['id_2']); ?></td>
						<td id="id"><?php echo e($post['id_3']); ?></td>
						<td id="desc"><?php echo e($post['description']); ?></td>
						<td id="impl"><?php echo e($post['implementation']); ?></td>
						<td id="lev"><?php echo e($post['level']); ?></td>
						<td>
							<a href="<?php echo e(action('CrudsController@edit',$post['id'])); ?>" class="btn btn-warning">
								<button id="modifica" class="btn btn-danger" type="submit">Modifica</button>
							</a>
						</td>
						<td>
							
						</td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>			

			<br><br><br><br><br>
			
	</body>
</html>